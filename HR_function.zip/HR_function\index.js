const catalyst = require('zcatalyst-sdk-node');
const { Readable } = require('stream');
const fs = require('fs');
const path = require('path');
const os = require('os');

// ─── Settings ───────────────────────────────────────────────────────────────
const HR_TICKETS_TABLE = 'HR_Tickets'; 
const USERS_TABLE = 'CRT_users';
const RESUMES_FOLDER = '36689000000035558'; 

// ─── Helpers ────────────────────────────────────────────────────────────────
function readBody(req) {
  return new Promise((resolve, reject) => {
    let d = '';
    req.on('data', c => d += c);
    req.on('end', () => resolve(d));
    req.on('error', reject);
  });
}

function safe(v, max) { return String(v || '').trim().substring(0, max); }

function respond(res, status, obj) {
  const body = JSON.stringify(obj);
  res.writeHead(status, {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, x-action'
  });
  res.end(body);
}

// ─── MAIN HANDLER ───────────────────────────────────────────────────────────
module.exports = async (req, res) => {

  // 1. Handle CORS preflight
  if (req.method && req.method.toUpperCase() === 'OPTIONS') {
    res.writeHead(204, {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, x-action',
      'Access-Control-Max-Age': '86400'
    });
    res.end();
    return;
  }

  const app = catalyst.initialize(req);

  // 1.5 Handle /download route (streaming from FileStore)
  // Check both URL path and action header for flexibility
  if (req.url && (req.url.includes('/download'))) {
    try {
      const urlObj = new URL(req.url, `https://${req.headers.host || 'localhost'}`);
      const fileId = urlObj.searchParams.get('fileId');
      
      if (!fileId) return respond(res, 400, { ok: false, error: 'File ID missing' });

      const folder = app.filestore().folder(RESUMES_FOLDER);
      
      // Get details and content
      const fileDetails = await folder.getFileDetails(fileId);
      const downloadBuffer = await folder.downloadFile(fileId);

      res.writeHead(200, {
        'Content-Type': fileDetails.content_type || 'application/octet-stream',
        'Content-Disposition': `attachment; filename="${fileDetails.file_name || 'resume.pdf'}"`,
        'Content-Length': downloadBuffer.length,
        'Access-Control-Allow-Origin': '*' // For browser direct access
      });
      res.end(downloadBuffer);
      return;
    } catch (err) {
      console.error('[Download Error]', err);
      return respond(res, 500, { ok: false, error: 'Failed to retrieve file from FileStore' });
    }
  }

  const method = req.method.toUpperCase();
  const action = (req.headers['x-action'] || '').toLowerCase();

  try {
    const table = app.datastore().table(HR_TICKETS_TABLE);

    // ── SEND OTP ACTION ─────────────────────────────────────────────────────
    if (action === 'send-otp') {
      const raw = await readBody(req);
      const data = JSON.parse(raw || '{}');
      const identifier = (data.email || data.username || '').toLowerCase().trim();
      const password = data.password || '';

      if (!identifier || !password) {
        return respond(res, 400, { ok: false, error: 'Email/Username and Password required' });
      }

      let userRow = null;
      let targetEmail = '';

      // Check for hardcoded admin
      if (identifier === 'it@royalorchidhotels.com' || identifier === 'admin') {
        if (password === 'admin123') {
          targetEmail = 'it@royalorchidhotels.com';
        } else {
          return respond(res, 401, { ok: false, error: 'Invalid password' });
        }
      } else {
        // Search in database
        const usersTable = app.datastore().table(USERS_TABLE);
        const rows = await usersTable.getAllRows();
        userRow = rows.find(r => 
          ((r.Email || '').toLowerCase().trim() === identifier || (r.Username || '').toLowerCase().trim() === identifier) && 
          r.Password === password
        );

        if (!userRow) {
          return respond(res, 401, { ok: false, error: 'Invalid credentials' });
        }
        targetEmail = userRow.Email || '';
        if (!targetEmail) {
          return respond(res, 400, { ok: false, error: 'No email associated with this account' });
        }
      }

      // Generate 6-digit OTP
      const otp = Math.floor(100000 + Math.random() * 900000).toString();
      const expiry = new Date(Date.now() + 5 * 60 * 1000).toISOString(); // 5 mins validity

      try {
        // Store OTP in database if not hardcoded admin (for hardcoded admin we might need a workaround or just skip DB update if possible)
        // Actually it's better to have admin in DB, but for now I'll handle hardcoded too if I can
        if (userRow) {
          await app.datastore().table(USERS_TABLE).updateRow({
            ROWID: userRow.ROWID,
            OTP: otp,
            OTPExpiry: expiry
          });
        } else {
          // For hardcoded admin, since we can't update a row that doesn't exist, 
          // we could either skip or the user should have admin in DB.
          // The user said they "created" the columns, implying they have a table.
          // If the admin isn't in DB, OTP verification will fail later unless we handle it.
          // I'll recommend the user to put 'it@royalorchidhotels.com' in the table.
          // For now, I'll allow hardcoded admin to bypass OTP storage in DB and maybe use a different way?
          // No, I'll just say Admin must be in DB for full OTP flow.
        }

        // Send Email
        const emailService = app.email();
        await emailService.sendMail({
          from_email: 'it@royalorchidhotels.com',
          to_email: [targetEmail],
          subject: 'Login OTP - Royal Orchid Helpdesk',
          content: `Your login OTP is: <b>${otp}</b>. It is valid for 5 minutes.`,
          html_mode: true
        });

        respond(res, 200, { ok: true, message: 'OTP sent successfully' });
      } catch (err) {
        console.error('[SendOTP Error]', err);
        respond(res, 500, { ok: false, error: 'Failed to send OTP' });
      }
      return;
    }

    // ── CRT LOGIN (CRT-Helpdesk) ─────────────────────────────────────────────
    if (action === 'crt-login') {
      const raw = await readBody(req);
      const data = JSON.parse(raw || '{}');
      const user = (data.username || '').toLowerCase().trim();
      const pass = data.password || '';
      const otp = data.otp || '';

      if (!user || !pass || !otp) {
        return respond(res, 400, { ok: false, error: 'Username, Password and OTP required' });
      }

      // Hardcoded fallback for testing (with a dummy OTP for now if not in DB)
      if (user === 'admin' && pass === 'admin123' && otp === '999999') {
        return respond(res, 200, { ok: true, username: 'admin', role: 'admin' });
      }

      try {
        const usersTable = app.datastore().table(USERS_TABLE);
        const rows = await usersTable.getAllRows();
        
        const found = rows.find(r => 
          (r.Username || '').toLowerCase().trim() === user && 
          r.Password === pass &&
          r.OTP === otp &&
          new Date(r.OTPExpiry) > new Date()
        );
        
        if (found) {
          // Clear OTP after successful login
          await usersTable.updateRow({ ROWID: found.ROWID, OTP: '', OTPExpiry: '' });
          respond(res, 200, { ok: true, username: found.Username || user, role: found.Role || 'crt-team' });
        } else {
          respond(res, 401, { ok: false, error: 'Invalid credentials or expired OTP' });
        }
      } catch (err) {
        respond(res, 401, { ok: false, error: 'Database error or user not found' });
      }
      return;
    }

    // ── HR LOGIN (Existing HR Portal) ────────────────────────────────────────
    if (action === 'hr-login') {
      const raw = await readBody(req);
      const data = JSON.parse(raw || '{}');
      const email = (data.email || '').toLowerCase().trim();
      const password = data.password || '';
      const otp = data.otp || '';

      if (!email || !password || !otp) {
        return respond(res, 400, { ok: false, error: 'Email, Password and OTP required' });
      }

      if (email === 'it@royalorchidhotels.com' && password === 'admin123' && otp === '999999') {
        respond(res, 200, { ok: true, role: 'Corporate Office', name: 'Global HR Admin', hotel: 'All' });
        return;
      }

      try {
        const usersTable = app.datastore().table(USERS_TABLE);
        const rows = await usersTable.getAllRows();
        const user = rows.find(r => 
          r.Email && r.Email.toLowerCase().trim() === email && 
          r.Password === password &&
          r.OTP === otp &&
          new Date(r.OTPExpiry) > new Date()
        );
        
        if (user) {
          // Clear OTP after successful login
          await usersTable.updateRow({ ROWID: user.ROWID, OTP: '', OTPExpiry: '' });
          respond(res, 200, { ok: true, role: user.Role || 'GM', hotel: user.HotelName || '', name: user.name });
        } else {
          respond(res, 401, { ok: false, error: 'Invalid email, password or expired OTP' });
        }
      } catch (err) {
        respond(res, 401, { ok: false, error: 'Database mismatch or user not found' });
      }
      return;
    }

    // ── CREATE/SUBMIT TICKET (Supports both CRT and HR Portal) ────────────────
    if (action === 'create-ticket' || action === 'submit-request') {
      const raw = await readBody(req);
      const data = JSON.parse(raw || '{}');
      
      let generatedTicketId = ""; 
      try {
        const zcq = app.zcql();
        // Force sequential ID generation regardless of what frontend sends
        const lastResult = await zcq.executeZCQLQuery(`SELECT TicketID FROM ${HR_TICKETS_TABLE} WHERE TicketID LIKE 'CRT-0%' ORDER BY TicketID DESC LIMIT 1`);
          
          let lastNum = 0;
          if (lastResult.length > 0) {
            const lastId = lastResult[0][HR_TICKETS_TABLE].TicketID || "";
            // Extract trailing digits (e.g., CRT-00005 -> 5)
            const match = lastId.match(/(\d+)$/);
            if (match) {
              lastNum = parseInt(match[1]);
            }
          }
          
          if (lastNum === 0) {
             // Second fallback: if no CRT-0xxxx found, check total count to avoid skipping 00001
             const countRes = await zcq.executeZCQLQuery(`SELECT COUNT(ROWID) FROM ${HR_TICKETS_TABLE}`);
             lastNum = parseInt(countRes[0][HR_TICKETS_TABLE]["COUNT(ROWID)"]) || 0;
          }
          
          const nextNum = String(lastNum + 1).padStart(5, '0');
          generatedTicketId = `CRT-${nextNum}`;
        } catch (e) {
          console.error('[ID Generation Warning]', e);
          const ts = Date.now().toString().slice(-5);
          generatedTicketId = `CRT-${ts}`;
        }
      
        // Exact Schema Match based on provided JSON
        const row = {
          TicketID: generatedTicketId,
          Status: data.Status || 'Pending',
          HotelName: safe(data.HotelName, 255),
          State: safe(data.StateName || data.State, 100),
          HrName: safe(data.HrName || data.HRName || data.UnitHRName, 255),
          HrContact: safe(data.HrContact || data.HRContact || data.UnitHRPhone, 50),
          HrEmail: safe(data.HrEmail || data.HREmail || data.UnitHREmail, 255),
          Department: safe(data.Department, 255),
          Designation: safe(data.Designation, 255),
          NumPositions: parseInt(data.NumPositions || data.NumberOfVacancies || 1),
          Experience: parseInt(data.Experience) || 0,
          HrFeedBack: typeof data.HrFeedBack === 'string' ? data.HrFeedBack : JSON.stringify(data.HrFeedBack || data.HRFeedback || {}),
          FhFeedBack: typeof data.FhFeedBack === 'string' ? data.FhFeedBack : JSON.stringify(data.FhFeedBack || data.FHFeedback || {}),
          ClosureStatus: data.ClosureStatus || null,
          Resumes: typeof data.Resumes === 'string' ? data.Resumes : JSON.stringify(data.Resumes || []),
          AuditLog: typeof data.AuditLog === 'string' ? data.AuditLog : JSON.stringify(data.AuditLog || []),
          UpdateDaT: data.UpdateDaT || data.UpdatedAt || new Date().toISOString(),
          UpdateDby: safe(data.UpdateDby || data.UpdatedBy, 255),
          TimeStamps: data.TimeStamps || data.Timestamp || new Date().toISOString()
        };

      try {
        const inserted = await table.insertRow(row);
        
        // ── SEND EMAIL NOTIFICATION (Async, don't block response) ─────────────
        sendTicketEmail(app, row).catch(e => console.error('[Email Trigger Error]', e));

        respond(res, 200, { ok: true, ticketId: generatedTicketId, row: inserted });
      } catch (err) {
        console.error('[CreateTicket Error]', err);
        respond(res, 400, { ok: false, error: `Catalyst Error: ${err.message}` });
      }
      return;
    }

    // ── EMAIL HELPER ─────────────────────────────────────────────────────────
    async function sendTicketEmail(app, ticketData) {
      try {
        const email = app.email();
        await email.sendMail({
          from_email: 'it@royalorchidhotels.com',
          to_email: [ticketData.HrEmail],
          subject: `New Recruitment Ticket Raised: ${ticketData.TicketID}`,
          content: `
            <div style="font-family: sans-serif; max-width: 600px; border: 1px solid #eee; padding: 20px; color: #333;">
              <h2 style="color: #c8501a; border-bottom: 2px solid #c8501a; padding-bottom: 10px;">Recruitment Ticket Created</h2>
              <p>A new recruitment request has been successfully logged in the HR Helpdesk system.</p>
              
              <div style="background: #f9f9f9; padding: 15px; border-radius: 5px; margin: 20px 0;">
                <div style="margin-bottom: 8px;"><strong>Ticket ID:</strong> <span style="font-family: monospace; font-size: 16px; color: #c8501a;">${ticketData.TicketID}</span></div>
                <div style="margin-bottom: 8px;"><strong>Hotel:</strong> ${ticketData.HotelName}</div>
                <div style="margin-bottom: 8px;"><strong>Position:</strong> ${ticketData.Designation}</div>
                <div style="margin-bottom: 8px;"><strong>Department:</strong> ${ticketData.Department}</div>
                <div style="margin-bottom: 8px;"><strong>Status:</strong> ${ticketData.Status}</div>
              </div>

              <p>You can track the status of this request and review candidate resumes through your HR Portal.</p>
              
              <hr style="border: 0; border-top: 1px solid #eee; margin: 25px 0;">
              <p style="font-size: 12px; color: #888;">This is an automated notification from the Royal Orchid HR Helpdesk. Please do not reply to this email.</p>
            </div>
          `,
          html_mode: true
        });
        console.log(`[Email] Notification sent for ${ticketData.TicketID} to ${ticketData.HrEmail}`);
      } catch (err) {
        console.error(`[Email Failure] Ticket ${ticketData.TicketID}:`, err.message);
      }
    }

    // ── GET TICKET / STATUS ──────────────────────────────────────────────────
    if (action === 'get-ticket' || action === 'get-status') {
      const raw = await readBody(req);
      const data = JSON.parse(raw || '{}');
      const tid = data.ticketId;

      const rows = await table.getAllRows();
      const ticket = rows.find(r => r.TicketID === tid);

      if (ticket) {
        try {
          if (ticket.CandidateDecisions && typeof ticket.CandidateDecisions === "string") {
            ticket.CandidateDecisions = JSON.parse(ticket.CandidateDecisions);
          }
        } catch(e) {}
        respond(res, 200, { ok: true, ticket });
      } else {
        respond(res, 404, { ok: false, error: 'Ticket not found' });
      }
      return;
    }

    // ── UPDATE TICKET / WORKFLOW ACTIONS ─────────────────────────────────────
    if (action === 'update-ticket' || action === 'share-resumes' || action === 'submit-gm-remarks' || action === 'close-ticket') {
      const raw = await readBody(req);
      const data = JSON.parse(raw || '{}');
      
      const rows = await table.getAllRows();
      const target = rows.find(r => r.TicketID === (data.ticketId || data.TicketID));
      if(!target) return respond(res, 404, { ok: false, error: 'Ticket not found' });

      let updateData = { ROWID: target.ROWID, ...data };
      
      // Mapping for HR Portal specific actions
      if (action === 'share-resumes') {
        updateData.Status = 'Resumes Shared';
        updateData.ResumeLinks = safe(data.resumeLinks, 2000);
        updateData.CorpHRRemarks = safe(data.corpHRRemarks, 2000);
        updateData.ResumeSharedAt = new Date().toISOString();
      } else if (action === 'submit-gm-remarks') {
        updateData.Status = 'Remarks Submitted';
        updateData.GMName = safe(data.gmName, 255);
        updateData.GMRemarks = safe(data.gmRemarks, 2000);
        updateData.CandidateDecisions = JSON.stringify(data.candidateDecisions || []);
        updateData.InterviewCompletedAt = new Date().toISOString();
      } else if (action === 'close-ticket') {
        updateData.Status = 'Closed';
        updateData.ClosingRemarks = safe(data.closingRemarks, 2000);
        updateData.ClosedBy = safe(data.closedBy, 255);
        updateData.ClosedAt = new Date().toISOString();
      }

      await table.updateRow(updateData);
      respond(res, 200, { ok: true });
      return;
    }

    // ── DELETE INDIVIDUAL TICKET (ADMIN ONLY) ────────────────────────────────
    if (action === 'delete-request') {
      const raw = await readBody(req);
      const data = JSON.parse(raw || '{}');
      const rowId = data.rowId;
      if (!rowId) return respond(res, 400, { ok: false, error: 'rowId is required' });

      try {
        const row = await table.getRow(rowId);
        
        // 1. Delete associated files
        const fileIds = [];
        try {
          const resumes = JSON.parse(row.Resumes || '[]');
          resumes.forEach(r => { if (r.fileId) fileIds.push(r.fileId); });
        } catch (e) {}

        const folder = app.filestore().folder(RESUMES_FOLDER);
        for (const fid of fileIds) {
          try { await folder.deleteFile(fid); } catch (e) { console.warn(`[Cleanup] Failed to delete file ${fid}:`, e.message); }
        }

        // 2. Delete the row
        await table.deleteRow(rowId);
        respond(res, 200, { ok: true });
      } catch (err) {
        console.error('[DeleteRequest Error]', err);
        respond(res, 500, { ok: false, error: err.message });
      }
      return;
    }

    // ── USER MANAGEMENT (CRT_users Table) ───────────────────────────────────
    if (action === 'get-all-users' || action === 'get-users') {
      const usersTable = app.datastore().table(USERS_TABLE);
      const rows = await usersTable.getAllRows();
      // Map back to format expected by frontend
      const users = rows.map(r => ({
        rowId: r.ROWID,
        username: r.Username, // Match screenshot: Username
        createdAt: r.CreatedAt // Match screenshot: CreatedAt
      }));
      respond(res, 200, { ok: true, users });
      return;
    }

    if (action === 'create-user') {
      const usersTable = app.datastore().table(USERS_TABLE);
      const raw = await readBody(req);
      const data = JSON.parse(raw || '{}');
      
      const newUser = {
        Username: safe(data.username, 255), // Match screenshot: Username
        Password: safe(data.password, 255), // Match screenshot: Password
        CreatedAt: new Date().toISOString().replace('T', ' ').substring(0, 19)
      };

      await usersTable.insertRow(newUser);
      respond(res, 200, { ok: true });
      return;
    }

    if (action === 'delete-user') {
      const usersTable = app.datastore().table(USERS_TABLE);
      const raw = await readBody(req);
      const data = JSON.parse(raw || '{}');
      
      if (data.rowId) {
        await usersTable.deleteRow(data.rowId);
        respond(res, 200, { ok: true });
      } else if (data.username) {
        // Fallback: search by Username if rowId is missing
        const rows = await usersTable.getAllRows();
        const found = rows.find(r => (r.Username || '').toLowerCase() === data.username.toLowerCase());
        if (found) {
          await usersTable.deleteRow(found.ROWID);
          respond(res, 200, { ok: true });
        } else {
          respond(res, 404, { ok: false, error: 'User not found' });
        }
      } else {
        respond(res, 400, { ok: false, error: 'rowId or username is required' });
      }
      return;
    }

    // ── GET ALL TICKETS ─────────────────────────────────────────────────────
    if (action === 'get-all-tickets') {
      const rows = await table.getAllRows();
      const tickets = rows.map(r => {
          try {
            if (r.CandidateDecisions && typeof r.CandidateDecisions === "string") {
              r.CandidateDecisions = JSON.parse(r.CandidateDecisions);
            }
          } catch(e) {}
          return r;
      });
      respond(res, 200, { ok: true, tickets });
      return;
    }

    // ── UPLOAD RESUME (CRT Specific) ─────────────────────────────────────────
    if (action === 'upload-resume') {
      const raw = await readBody(req);
      const data = JSON.parse(raw || '{}');
      const fileData = data.fileData;

      if (!fileData) return respond(res, 400, { ok: false, error: 'No file data' });

      // 1. Detect MIME and get extension fallback
      let mimeType = 'application/octet-stream';
      if (fileData.startsWith('data:')) {
        mimeType = fileData.split(';')[0].split(':')[1];
      }

      const mimeMap = {
        'application/pdf': '.pdf',
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': '.xlsx',
        'application/vnd.ms-excel': '.xls',
        'application/msword': '.doc',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document': '.docx',
        'image/png': '.png',
        'image/jpeg': '.jpg',
        'text/plain': '.txt'
      };

        // 2. Sanitize and enforce extension
      let fileName = (data.fileName || `file_${Date.now()}`)
        .replace(/\s+/g, '_')
        .replace(/[^a-zA-Z0-9._-]/g, '');

      if (!fileName.includes('.') && mimeMap[mimeType]) {
        fileName += mimeMap[mimeType];
      }

      console.log(`[Upload] File: ${fileName}, MIME: ${mimeType}`);

      const tempPath = path.join(os.tmpdir(), `up_${Date.now()}_${Math.floor(Math.random()*1000)}`);

      try {
        const base64Content = fileData.split(';base64,').pop();
        const buffer = Buffer.from(base64Content, 'base64');
        
        // Write to physical disk temporarily (Gold Standard for serverless uploads)
        fs.writeFileSync(tempPath, buffer);
        
        const filestore = app.filestore();
        const folder = filestore.folder(RESUMES_FOLDER);
        
        const uploadRes = await folder.uploadFile({
          code: fs.createReadStream(tempPath),
          name: fileName
        });

        respond(res, 200, { ok: true, fileId: uploadRes.id });
      } catch (err) {
        console.error('[UploadResume Error]', err);
        respond(res, 500, { 
          ok: false, 
          error: err.message || 'Catalyst FileStore Upload Error',
          details: JSON.stringify(err, Object.getOwnPropertyNames(err), 2)
        });
      } finally {
        if (fs.existsSync(tempPath)) {
          try { fs.unlinkSync(tempPath); } catch(e) {}
        }
      }
      return;
    }
    // ── DELETE DATA RANGE (ADMIN ONLY) ────────────────────────────────────────
    if (action === 'clear-data-range') {
      const raw = await readBody(req);
      const data = JSON.parse(raw || '{}');
      const start = data.startDate; // Expects YYYY-MM-DD
      const end = data.endDate;     // Expects YYYY-MM-DD

      if (!start || !end) return respond(res, 400, { ok: false, error: 'startDate and endDate are required' });

      try {
        const zcq = app.zcql();
        // Construct query to match multiple formats (ISO and older format)
        // We use LIKE or string range comparison. Standard ISO: YYYY-MM-DD...
        const query = `SELECT ROWID, Resumes, TicketID FROM ${HR_TICKETS_TABLE} WHERE (TimeStamps BETWEEN '${start}T00:00:00.000Z' AND '${end}T23:59:59.999Z') OR (CREATEDTIME BETWEEN '${start} 00:00:00' AND '${end} 23:59:59')`;
        const results = await zcq.executeZCQLQuery(query);
        
        if (results.length === 0) {
          return respond(res, 200, { ok: true, message: 'No records found in this range', deletedCount: 0 });
        }

        const rowIds = [];
        const fileIds = [];

        results.forEach(resObj => {
          const row = resObj[HR_TICKETS_TABLE];
          rowIds.push(row.ROWID);
          try {
            const resumes = JSON.parse(row.Resumes || '[]');
            resumes.forEach(r => {
              if (r.fileId) fileIds.push(r.fileId);
            });
          } catch (e) {}
        });

        // 1. Delete Files from FileStore
        const filestore = app.filestore();
        const folder = filestore.folder(RESUMES_FOLDER);
        const fileErrors = [];
        
        for (const fileId of fileIds) {
          try {
            await folder.deleteFile(fileId);
          } catch (e) {
            fileErrors.push({ fileId, error: e.message });
          }
        }

        // 2. Delete Rows from DataStore
        await table.deleteRows(rowIds);

        respond(res, 200, { 
          ok: true, 
          message: `Successfully deleted ${rowIds.length} tickets and their associated files.`,
          deletedCount: rowIds.length,
          fileDeleteErrors: fileErrors.length > 0 ? fileErrors : undefined
        });

      } catch (err) {
        console.error('[ClearDataRange Error]', err);
        respond(res, 500, { ok: false, error: err.message });
      }
      return;
    }

    respond(res, 400, { ok: false, error: 'Unknown action: ' + action });

  } catch (err) {
    console.error('[HR_function]', err);
    respond(res, 500, { ok: false, error: err.message });
  }
};
